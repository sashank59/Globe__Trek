package com.example.globetrek.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.model.WishlistItem
import com.example.globetrek.data.repository.WishlistRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class WishlistViewModel(
    private val wishlistRepository: WishlistRepository = WishlistRepository()
) : ViewModel() {

    private val _wishlistState = MutableLiveData<Resource<List<WishlistItem>>>()
    val wishlistState: LiveData<Resource<List<WishlistItem>>> = _wishlistState

    init {
        observeWishlist()
    }

    fun observeWishlist() {
        viewModelScope.launch {
            wishlistRepository.getWishlistFlow().collectLatest { resource ->
                _wishlistState.value = resource
            }
        }
    }

    fun removeItem(countryCode: String) {
        viewModelScope.launch {
            wishlistRepository.removeFromWishlist(countryCode)
        }
    }
}
