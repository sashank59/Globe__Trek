package com.example.globetrek.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.globetrek.data.model.Country
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.repository.CountryRepository
import com.example.globetrek.data.repository.WishlistRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DetailsViewModel(
    private val countryRepository: CountryRepository = CountryRepository(),
    private val wishlistRepository: WishlistRepository = WishlistRepository()
) : ViewModel() {

    private val _countryState = MutableLiveData<Resource<Country>>()
    val countryState: LiveData<Resource<Country>> = _countryState

    private val _isSavedInWishlist = MutableLiveData<Boolean>(false)
    val isSavedInWishlist: LiveData<Boolean> = _isSavedInWishlist

    fun loadCountryDetails(countryCode: String) {
        _countryState.value = Resource.Loading()
        viewModelScope.launch {
            val result = countryRepository.getCountryByCode(countryCode)
            _countryState.value = result
            if (result is Resource.Success && result.data != null) {
                observeWishlistState(result.data.countryCode)
            }
        }
    }

    fun loadCountryFromObject(country: Country) {
        _countryState.value = Resource.Success(country)
        observeWishlistState(country.countryCode)
    }

    private fun observeWishlistState(countryCode: String) {
        viewModelScope.launch {
            wishlistRepository.isCountrySavedFlow(countryCode).collectLatest { isSaved ->
                _isSavedInWishlist.value = isSaved
            }
        }
    }

    fun toggleWishlist() {
        val currentCountry = (_countryState.value as? Resource.Success)?.data ?: return
        viewModelScope.launch {
            if (_isSavedInWishlist.value == true) {
                wishlistRepository.removeFromWishlist(currentCountry.countryCode)
            } else {
                wishlistRepository.addToWishlist(currentCountry)
            }
        }
    }
}
