package com.example.globetrek.data.repository

import com.example.globetrek.data.model.Country
import com.example.globetrek.data.model.CountryFlags
import com.example.globetrek.data.model.CountryName
import com.example.globetrek.data.model.CurrencyInfo
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.remote.CountryApiService
import com.example.globetrek.data.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CountryRepository(
    private val apiService: CountryApiService = RetrofitClient.apiService
) {

    suspend fun getAllCountries(): Resource<List<Country>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getAllCountries()
            val body = response.body()
            if (response.isSuccessful && !body.isNullOrEmpty()) {
                val list = body.sortedBy { it.commonName }
                Resource.Success(list)
            } else {
                Resource.Success(getFallbackCountries())
            }
        } catch (e: Exception) {
            Resource.Success(getFallbackCountries())
        }
    }

    suspend fun searchCountries(query: String): Resource<List<Country>> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            return@withContext getAllCountries()
        }

        try {
            val response = apiService.getCountriesByName(trimmed)
            val body = response.body()
            if (response.isSuccessful && !body.isNullOrEmpty()) {
                val list = body.sortedBy { it.commonName }
                Resource.Success(list)
            } else {
                val fallbackList = getFallbackCountries().filter {
                    it.commonName.contains(trimmed, ignoreCase = true) ||
                    it.officialName.contains(trimmed, ignoreCase = true) ||
                    it.countryCode.equals(trimmed, ignoreCase = true)
                }
                if (fallbackList.isNotEmpty()) {
                    Resource.Success(fallbackList)
                } else {
                    Resource.Error("No countries found matching \"$trimmed\"")
                }
            }
        } catch (e: Exception) {
            val fallbackList = getFallbackCountries().filter {
                it.commonName.contains(trimmed, ignoreCase = true) ||
                it.officialName.contains(trimmed, ignoreCase = true) ||
                it.countryCode.equals(trimmed, ignoreCase = true)
            }
            if (fallbackList.isNotEmpty()) {
                Resource.Success(fallbackList)
            } else {
                Resource.Error("Network error. Could not search countries.")
            }
        }
    }

    suspend fun getCountryByCode(code: String): Resource<Country> = withContext(Dispatchers.IO) {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.isEmpty()) {
            return@withContext Resource.Error<Country>("Invalid country code")
        }

        try {
            val response = apiService.getCountryByCode(cleanCode)
            val body = response.body()
            if (response.isSuccessful && !body.isNullOrEmpty()) {
                val country: Country = body.first()
                return@withContext Resource.Success<Country>(country)
            }
            val fallback = getFallbackCountries().find {
                it.countryCode.equals(cleanCode, ignoreCase = true) ||
                it.cca3?.equals(cleanCode, ignoreCase = true) == true
            }
            if (fallback != null) {
                return@withContext Resource.Success(fallback)
            }
            return@withContext Resource.Error<Country>("Country details not found for code: $cleanCode")
        } catch (e: Exception) {
            val fallback = getFallbackCountries().find {
                it.countryCode.equals(cleanCode, ignoreCase = true) ||
                it.cca3?.equals(cleanCode, ignoreCase = true) == true
            }
            if (fallback != null) {
                return@withContext Resource.Success(fallback)
            }
            return@withContext Resource.Error<Country>("Network error. Could not fetch country details.")
        }
    }

    private fun getFallbackCountries(): List<Country> {
        return listOf(
            Country(
                name = CountryName("United States", "United States of America"),
                cca2 = "US",
                cca3 = "USA",
                capital = listOf("Washington, D.C."),
                region = "Americas",
                subregion = "North America",
                population = 331893745,
                flags = CountryFlags("https://flagcdn.com/w320/us.png"),
                currencies = mapOf("USD" to CurrencyInfo("United States Dollar", "$")),
                languages = mapOf("eng" to "English")
            ),
            Country(
                name = CountryName("Japan", "Japan"),
                cca2 = "JP",
                cca3 = "JPN",
                capital = listOf("Tokyo"),
                region = "Asia",
                subregion = "Eastern Asia",
                population = 125680000,
                flags = CountryFlags("https://flagcdn.com/w320/jp.png"),
                currencies = mapOf("JPY" to CurrencyInfo("Japanese Yen", "¥")),
                languages = mapOf("jpn" to "Japanese")
            ),
            Country(
                name = CountryName("France", "French Republic"),
                cca2 = "FR",
                cca3 = "FRA",
                capital = listOf("Paris"),
                region = "Europe",
                subregion = "Western Europe",
                population = 67750000,
                flags = CountryFlags("https://flagcdn.com/w320/fr.png"),
                currencies = mapOf("EUR" to CurrencyInfo("Euro", "€")),
                languages = mapOf("fra" to "French")
            ),
            Country(
                name = CountryName("India", "Republic of India"),
                cca2 = "IN",
                cca3 = "IND",
                capital = listOf("New Delhi"),
                region = "Asia",
                subregion = "Southern Asia",
                population = 1408044253,
                flags = CountryFlags("https://flagcdn.com/w320/in.png"),
                currencies = mapOf("INR" to CurrencyInfo("Indian Rupee", "₹")),
                languages = mapOf("hin" to "Hindi", "eng" to "English")
            ),
            Country(
                name = CountryName("Brazil", "Federative Republic of Brazil"),
                cca2 = "BR",
                cca3 = "BRA",
                capital = listOf("Brasília"),
                region = "Americas",
                subregion = "South America",
                population = 214300000,
                flags = CountryFlags("https://flagcdn.com/w320/br.png"),
                currencies = mapOf("BRL" to CurrencyInfo("Brazilian Real", "R$")),
                languages = mapOf("por" to "Portuguese")
            ),
            Country(
                name = CountryName("Australia", "Commonwealth of Australia"),
                cca2 = "AU",
                cca3 = "AUS",
                capital = listOf("Canberra"),
                region = "Oceania",
                subregion = "Australia and New Zealand",
                population = 25690000,
                flags = CountryFlags("https://flagcdn.com/w320/au.png"),
                currencies = mapOf("AUD" to CurrencyInfo("Australian Dollar", "$")),
                languages = mapOf("eng" to "English")
            ),
            Country(
                name = CountryName("Egypt", "Arab Republic of Egypt"),
                cca2 = "EG",
                cca3 = "EGY",
                capital = listOf("Cairo"),
                region = "Africa",
                subregion = "Northern Africa",
                population = 104300000,
                flags = CountryFlags("https://flagcdn.com/w320/eg.png"),
                currencies = mapOf("EGP" to CurrencyInfo("Egyptian Pound", "E£")),
                languages = mapOf("ara" to "Arabic")
            ),
            Country(
                name = CountryName("Germany", "Federal Republic of Germany"),
                cca2 = "DE",
                cca3 = "DEU",
                capital = listOf("Berlin"),
                region = "Europe",
                subregion = "Western Europe",
                population = 83200000,
                flags = CountryFlags("https://flagcdn.com/w320/de.png"),
                currencies = mapOf("EUR" to CurrencyInfo("Euro", "€")),
                languages = mapOf("deu" to "German")
            ),
            Country(
                name = CountryName("United Kingdom", "United Kingdom of Great Britain and Northern Ireland"),
                cca2 = "GB",
                cca3 = "GBR",
                capital = listOf("London"),
                region = "Europe",
                subregion = "Northern Europe",
                population = 67330000,
                flags = CountryFlags("https://flagcdn.com/w320/gb.png"),
                currencies = mapOf("GBP" to CurrencyInfo("British Pound", "£")),
                languages = mapOf("eng" to "English")
            ),
            Country(
                name = CountryName("Canada", "Canada"),
                cca2 = "CA",
                cca3 = "CAN",
                capital = listOf("Ottawa"),
                region = "Americas",
                subregion = "North America",
                population = 38250000,
                flags = CountryFlags("https://flagcdn.com/w320/ca.png"),
                currencies = mapOf("CAD" to CurrencyInfo("Canadian Dollar", "$")),
                languages = mapOf("eng" to "English", "fra" to "French")
            ),
            Country(
                name = CountryName("South Africa", "Republic of South Africa"),
                cca2 = "ZA",
                cca3 = "ZAF",
                capital = listOf("Pretoria", "Cape Town", "Bloemfontein"),
                region = "Africa",
                subregion = "Southern Africa",
                population = 59310000,
                flags = CountryFlags("https://flagcdn.com/w320/za.png"),
                currencies = mapOf("ZAR" to CurrencyInfo("South African Rand", "R")),
                languages = mapOf("eng" to "English", "afr" to "Afrikaans", "zul" to "Zulu")
            )
        )
    }
}
