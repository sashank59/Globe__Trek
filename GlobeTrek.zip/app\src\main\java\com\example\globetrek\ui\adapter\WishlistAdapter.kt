package com.example.globetrek.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.globetrek.R
import com.example.globetrek.data.model.WishlistItem
import com.example.globetrek.databinding.ItemWishlistBinding

class WishlistAdapter(
    private val onItemClick: (WishlistItem) -> Unit,
    private val onRemoveClick: (WishlistItem) -> Unit
) : ListAdapter<WishlistItem, WishlistAdapter.WishlistViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WishlistViewHolder {
        val binding = ItemWishlistBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return WishlistViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WishlistViewHolder, position: Int) {
        val item = getItem(position)
        if (item != null) {
            holder.bind(item)
        }
    }

    inner class WishlistViewHolder(
        private val binding: ItemWishlistBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: WishlistItem) {
            binding.tvWishlistCountryName.text = item.countryName
            val subtitle = buildString {
                if (item.region.isNotEmpty()) append(item.region).append(" • ")
                append(item.countryCode)
            }
            binding.tvWishlistRegion.text = subtitle

            Glide.with(binding.imgWishlistFlag.context)
                .load(item.flagUrl)
                .placeholder(R.drawable.ic_flag_placeholder)
                .error(R.drawable.ic_flag_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(binding.imgWishlistFlag)

            binding.root.setOnClickListener { onItemClick(item) }
            binding.btnRemove.setOnClickListener { onRemoveClick(item) }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<WishlistItem>() {
        override fun areItemsTheSame(oldItem: WishlistItem, newItem: WishlistItem): Boolean {
            return oldItem.countryCode == newItem.countryCode
        }

        override fun areContentsTheSame(oldItem: WishlistItem, newItem: WishlistItem): Boolean {
            return oldItem == newItem
        }
    }
}
