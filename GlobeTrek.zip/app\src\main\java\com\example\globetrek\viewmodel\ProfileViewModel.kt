package com.example.globetrek.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.repository.AuthRepository
import com.example.globetrek.data.repository.WishlistRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val authRepository: AuthRepository = AuthRepository(),
    private val wishlistRepository: WishlistRepository = WishlistRepository()
) : ViewModel() {

    val currentUser: FirebaseUser?
        get() = authRepository.currentUser

    private val _wishlistCount = MutableLiveData<Int>(0)
    val wishlistCount: LiveData<Int> = _wishlistCount

    init {
        observeWishlistCount()
    }

    private fun observeWishlistCount() {
        viewModelScope.launch {
            wishlistRepository.getWishlistFlow().collectLatest { res ->
                if (res is Resource.Success && res.data != null) {
                    _wishlistCount.value = res.data.size
                }
            }
        }
    }

    fun logout() {
        authRepository.logout()
    }
}
