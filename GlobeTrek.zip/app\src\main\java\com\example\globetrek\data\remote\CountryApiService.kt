package com.example.globetrek.data.remote

import com.example.globetrek.data.model.Country
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface CountryApiService {

    @GET("v3.1/all?fields=name,cca2,cca3,capital,region,subregion,population,flags,currencies,languages")
    suspend fun getAllCountries(): Response<List<Country>>

    @GET("v3.1/name/{name}?fields=name,cca2,cca3,capital,region,subregion,population,flags,currencies,languages")
    suspend fun getCountriesByName(@Path("name") name: String): Response<List<Country>>

    @GET("v3.1/alpha/{code}?fields=name,cca2,cca3,capital,region,subregion,population,flags,currencies,languages")
    suspend fun getCountryByCode(@Path("code") code: String): Response<List<Country>>
}
