package com.example.globetrek.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.repository.AuthRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _authResult = MutableLiveData<Resource<FirebaseUser>?>()
    val authResult: LiveData<Resource<FirebaseUser>?> = _authResult

    val currentUser: FirebaseUser?
        get() = authRepository.currentUser

    val isUserLoggedIn: Boolean
        get() = authRepository.isUserLoggedIn

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authResult.value = Resource.Error("Please fill in both email and password.")
            return
        }
        _authResult.value = Resource.Loading()
        viewModelScope.launch {
            _authResult.value = authRepository.loginWithEmail(email, pass)
        }
    }

    fun register(name: String, email: String, pass: String, confirmPass: String) {
        if (name.isBlank() || email.isBlank() || pass.isBlank() || confirmPass.isBlank()) {
            _authResult.value = Resource.Error("Please complete all required fields.")
            return
        }
        if (pass.length < 6) {
            _authResult.value = Resource.Error("Password must be at least 6 characters.")
            return
        }
        if (pass != confirmPass) {
            _authResult.value = Resource.Error("Passwords do not match.")
            return
        }
        _authResult.value = Resource.Loading()
        viewModelScope.launch {
            _authResult.value = authRepository.registerWithEmail(name, email, pass)
        }
    }

    fun signInWithGoogle(idToken: String) {
        _authResult.value = Resource.Loading()
        viewModelScope.launch {
            _authResult.value = authRepository.signInWithGoogleCredential(idToken)
        }
    }

    fun logout() {
        authRepository.logout()
    }

    fun resetAuthResult() {
        _authResult.value = null
    }
}
