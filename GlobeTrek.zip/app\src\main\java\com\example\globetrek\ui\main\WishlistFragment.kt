package com.example.globetrek.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.globetrek.data.model.Resource
import com.example.globetrek.databinding.FragmentWishlistBinding
import com.example.globetrek.ui.adapter.WishlistAdapter
import com.example.globetrek.ui.details.CountryDetailsActivity
import com.example.globetrek.viewmodel.WishlistViewModel

class WishlistFragment : Fragment() {

    private var _binding: FragmentWishlistBinding? = null
    private val binding get() = _binding!!

    private val viewModel: WishlistViewModel by viewModels()
    private lateinit var adapter: WishlistAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWishlistBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = WishlistAdapter(
            onItemClick = { item ->
                CountryDetailsActivity.start(requireContext(), item.countryCode)
            },
            onRemoveClick = { item ->
                viewModel.removeItem(item.countryCode)
                Toast.makeText(requireContext(), "Removed from wishlist", Toast.LENGTH_SHORT).show()
            }
        )
        binding.rvWishlist.layoutManager = LinearLayoutManager(requireContext())
        binding.rvWishlist.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.wishlistState.observe(viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    binding.pbWishlist.visibility = View.VISIBLE
                    binding.layoutWishlistEmpty.visibility = View.GONE
                }
                is Resource.Success -> {
                    binding.pbWishlist.visibility = View.GONE
                    val list = resource.data ?: emptyList()
                    if (list.isEmpty()) {
                        binding.layoutWishlistEmpty.visibility = View.VISIBLE
                    } else {
                        binding.layoutWishlistEmpty.visibility = View.GONE
                    }
                    adapter.submitList(list)
                }
                is Resource.Error -> {
                    binding.pbWishlist.visibility = View.GONE
                    binding.layoutWishlistEmpty.visibility = View.VISIBLE
                    adapter.submitList(emptyList())
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
