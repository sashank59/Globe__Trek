package com.example.globetrek.data.model

data class WishlistItem(
    val countryCode: String = "",
    val countryName: String = "",
    val flagUrl: String = "",
    val region: String = "",
    val addedAt: Long = System.currentTimeMillis()
)
