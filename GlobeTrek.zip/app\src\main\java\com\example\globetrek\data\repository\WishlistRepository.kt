package com.example.globetrek.data.repository

import com.example.globetrek.data.model.Country
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.model.WishlistItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class WishlistRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    private val currentUserId: String?
        get() = auth.currentUser?.uid

    private fun getUserWishlistRef() = currentUserId?.let { userId ->
        firestore.collection("users").document(userId).collection("wishlist")
    }

    suspend fun addToWishlist(country: Country): Resource<Unit> {
        val ref = getUserWishlistRef() ?: return Resource.Error("User not authenticated.")
        val code = country.countryCode.ifEmpty { return Resource.Error("Invalid country code.") }

        val item = hashMapOf(
            "countryCode" to code,
            "countryName" to country.commonName,
            "flagUrl" to country.flagUrl,
            "region" to (country.region ?: ""),
            "addedAt" to System.currentTimeMillis()
        )

        return try {
            ref.document(code).set(item).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Failed to add to wishlist.")
        }
    }

    suspend fun removeFromWishlist(countryCode: String): Resource<Unit> {
        val ref = getUserWishlistRef() ?: return Resource.Error("User not authenticated.")
        val code = countryCode.trim().uppercase()
        if (code.isEmpty()) return Resource.Error("Invalid country code.")

        return try {
            ref.document(code).delete().await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Failed to remove from wishlist.")
        }
    }

    fun getWishlistFlow(): Flow<Resource<List<WishlistItem>>> = callbackFlow {
        val ref = getUserWishlistRef()
        if (ref == null) {
            trySend(Resource.Error("User not authenticated."))
            close()
            return@callbackFlow
        }

        trySend(Resource.Loading())

        val listener = ref.orderBy("addedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Resource.Error(error.localizedMessage ?: "Firestore error."))
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val items = snapshot.documents.mapNotNull { doc ->
                        val code = doc.getString("countryCode") ?: doc.id
                        val name = doc.getString("countryName") ?: ""
                        val flag = doc.getString("flagUrl") ?: ""
                        val reg = doc.getString("region") ?: ""
                        val added = doc.getLong("addedAt") ?: System.currentTimeMillis()
                        WishlistItem(
                            countryCode = code,
                            countryName = name,
                            flagUrl = flag,
                            region = reg,
                            addedAt = added
                        )
                    }
                    trySend(Resource.Success(items))
                }
            }

        awaitClose { listener.remove() }
    }

    fun isCountrySavedFlow(countryCode: String): Flow<Boolean> = callbackFlow {
        val ref = getUserWishlistRef()
        val code = countryCode.trim().uppercase()
        if (ref == null || code.isEmpty()) {
            trySend(false)
            close()
            return@callbackFlow
        }

        val listener = ref.document(code).addSnapshotListener { snapshot, _ ->
            trySend(snapshot?.exists() == true)
        }

        awaitClose { listener.remove() }
    }
}
