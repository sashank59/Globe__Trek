package com.example.globetrek.ui.main

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.globetrek.R
import com.example.globetrek.data.model.Resource
import com.example.globetrek.databinding.FragmentHomeBinding
import com.example.globetrek.location.LocationHelper
import com.example.globetrek.ui.adapter.CountryAdapter
import com.example.globetrek.ui.details.CountryDetailsActivity
import com.example.globetrek.viewmodel.HomeViewModel
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var adapter: CountryAdapter
    private lateinit var locationHelper: LocationHelper

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            detectCountry()
        } else {
            Toast.makeText(
                requireContext(),
                getString(R.string.location_permission_required),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        locationHelper = LocationHelper(requireContext())
        setupRecyclerView()
        setupSearchAndChips()
        setupListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = CountryAdapter(
            onCountryClick = { country ->
                CountryDetailsActivity.start(requireContext(), country.countryCode)
            },
            onWishlistClick = { country ->
                viewModel.toggleWishlist(country)
            }
        )
        binding.rvCountries.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCountries.adapter = adapter
    }

    private fun setupSearchAndChips() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.onSearchQueryChanged(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.chipGroupRegions.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                val chip = binding.root.findViewById<Chip>(checkedIds[0])
                val region = chip?.text?.toString() ?: "All"
                viewModel.selectRegion(region)
            } else {
                viewModel.selectRegion("All")
            }
        }
    }

    private fun setupListeners() {
        binding.btnDetectCountry.setOnClickListener {
            checkPermissionAndDetectCountry()
        }

        binding.btnHomeRetry.setOnClickListener {
            viewModel.loadCountries()
        }
    }

    private fun checkPermissionAndDetectCountry() {
        val finePermission = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        val coarsePermission = ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (finePermission == PackageManager.PERMISSION_GRANTED ||
            coarsePermission == PackageManager.PERMISSION_GRANTED
        ) {
            detectCountry()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun detectCountry() {
        lifecycleScope.launch {
            Toast.makeText(requireContext(), getString(R.string.detecting_location), Toast.LENGTH_SHORT).show()
            val locationRes = locationHelper.getCurrentLocation()
            if (locationRes is Resource.Success && locationRes.data != null) {
                val codeRes = locationHelper.getCountryCodeFromLocation(locationRes.data)
                if (codeRes is Resource.Success && !codeRes.data.isNullOrEmpty()) {
                    CountryDetailsActivity.start(requireContext(), codeRes.data)
                } else {
                    Toast.makeText(
                        requireContext(),
                        codeRes.message ?: getString(R.string.geocoder_failed),
                        Toast.LENGTH_LONG
                    ).show()
                }
            } else {
                Toast.makeText(
                    requireContext(),
                    locationRes.message ?: getString(R.string.location_failed),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.countries.observe(viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    binding.pbHome.visibility = View.VISIBLE
                    binding.layoutHomeEmpty.visibility = View.GONE
                }
                is Resource.Success -> {
                    binding.pbHome.visibility = View.GONE
                    val list = resource.data ?: emptyList()
                    if (list.isEmpty()) {
                        binding.layoutHomeEmpty.visibility = View.VISIBLE
                        binding.tvHomeEmptyMessage.text = getString(R.string.no_countries_found)
                    } else {
                        binding.layoutHomeEmpty.visibility = View.GONE
                    }
                    adapter.submitList(list)
                }
                is Resource.Error -> {
                    binding.pbHome.visibility = View.GONE
                    binding.layoutHomeEmpty.visibility = View.VISIBLE
                    binding.tvHomeEmptyMessage.text = resource.message ?: getString(R.string.error_network)
                    adapter.submitList(emptyList())
                }
            }
        }

        viewModel.wishlistCodes.observe(viewLifecycleOwner) { codes ->
            adapter.updateWishlistCodes(codes)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
