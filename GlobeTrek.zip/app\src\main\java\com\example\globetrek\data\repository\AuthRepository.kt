package com.example.globetrek.data.repository

import com.example.globetrek.data.model.Resource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.tasks.await

class AuthRepository(
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    val currentUser: FirebaseUser?
        get() = firebaseAuth.currentUser

    val isUserLoggedIn: Boolean
        get() = firebaseAuth.currentUser != null

    suspend fun loginWithEmail(email: String, pass: String): Resource<FirebaseUser> {
        return try {
            val result = firebaseAuth.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user
            if (user != null) {
                Resource.Success(user)
            } else {
                Resource.Error("Authentication failed: null user.")
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Login failed.")
        }
    }

    suspend fun registerWithEmail(name: String, email: String, pass: String): Resource<FirebaseUser> {
        return try {
            val result = firebaseAuth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user
            if (user != null) {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(name.trim())
                    .build()
                user.updateProfile(profileUpdates).await()
                Resource.Success(user)
            } else {
                Resource.Error("Registration failed: null user.")
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Registration failed.")
        }
    }

    suspend fun signInWithGoogleCredential(idToken: String): Resource<FirebaseUser> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val result = firebaseAuth.signInWithCredential(credential).await()
            val user = result.user
            if (user != null) {
                Resource.Success(user)
            } else {
                Resource.Error("Google Sign-In failed.")
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Google Sign-In failed.")
        }
    }

    fun logout() {
        firebaseAuth.signOut()
    }
}
