package com.example.globetrek.ui.details

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.globetrek.R
import com.example.globetrek.data.model.Country
import com.example.globetrek.data.model.Resource
import com.example.globetrek.databinding.ActivityCountryDetailsBinding
import com.example.globetrek.viewmodel.DetailsViewModel
import java.text.NumberFormat
import java.util.Locale

class CountryDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCountryDetailsBinding
    private val viewModel: DetailsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCountryDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val countryCode = intent.getStringExtra(EXTRA_COUNTRY_CODE)
        if (!countryCode.isNullOrEmpty()) {
            viewModel.loadCountryDetails(countryCode)
        } else {
            Toast.makeText(this, "Country details not specified", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnToggleWishlist.setOnClickListener {
            viewModel.toggleWishlist()
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.countryState.observe(this) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    binding.pbDetails.visibility = View.VISIBLE
                }
                is Resource.Success -> {
                    binding.pbDetails.visibility = View.GONE
                    val country = resource.data
                    if (country != null) {
                        displayCountryDetails(country)
                    }
                }
                is Resource.Error -> {
                    binding.pbDetails.visibility = View.GONE
                    Toast.makeText(this, resource.message ?: "Failed to load country details", Toast.LENGTH_LONG).show()
                }
            }
        }

        viewModel.isSavedInWishlist.observe(this) { isSaved ->
            if (isSaved) {
                binding.btnToggleWishlist.text = getString(R.string.remove_from_wishlist)
                binding.btnToggleWishlist.setIconResource(R.drawable.ic_favorite_filled)
            } else {
                binding.btnToggleWishlist.text = getString(R.string.add_to_wishlist)
                binding.btnToggleWishlist.setIconResource(R.drawable.ic_favorite_border)
            }
        }
    }

    private fun displayCountryDetails(country: Country) {
        binding.collapsingToolbar.title = country.commonName
        binding.tvCommonName.text = country.commonName
        binding.tvOfficialName.text = country.officialName
        binding.tvCapital.text = country.formattedCapital

        val regionSub = buildString {
            append(country.region ?: "N/A")
            if (!country.subregion.isNullOrEmpty()) {
                append(" (").append(country.subregion).append(")")
            }
        }
        binding.tvRegionSubregion.text = regionSub

        val formattedPop = country.population?.let {
            NumberFormat.getInstance(Locale.US).format(it)
        } ?: "N/A"
        binding.tvPopulation.text = formattedPop

        val codeText = buildString {
            append(country.countryCode)
            if (!country.cca3.isNullOrEmpty()) {
                append(" (").append(country.cca3).append(")")
            }
        }
        binding.tvCountryCode.text = codeText

        binding.tvCurrencies.text = country.formattedCurrencies
        binding.tvLanguages.text = country.formattedLanguages

        Glide.with(this)
            .load(country.flagUrl)
            .placeholder(R.drawable.ic_flag_placeholder)
            .error(R.drawable.ic_flag_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(binding.imgLargeFlag)
    }

    companion object {
        private const val EXTRA_COUNTRY_CODE = "extra_country_code"

        fun start(context: Context, countryCode: String) {
            val intent = Intent(context, CountryDetailsActivity::class.java).apply {
                putExtra(EXTRA_COUNTRY_CODE, countryCode)
            }
            context.startActivity(intent)
        }
    }
}
