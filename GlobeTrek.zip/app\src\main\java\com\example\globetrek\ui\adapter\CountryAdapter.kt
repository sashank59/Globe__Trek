package com.example.globetrek.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.globetrek.R
import com.example.globetrek.data.model.Country
import com.example.globetrek.databinding.ItemCountryBinding

class CountryAdapter(
    private val onCountryClick: (Country) -> Unit,
    private val onWishlistClick: (Country) -> Unit
) : ListAdapter<Country, CountryAdapter.CountryViewHolder>(DiffCallback) {

    private var wishlistCodes: Set<String> = emptySet()

    fun updateWishlistCodes(codes: Set<String>) {
        this.wishlistCodes = codes
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val binding = ItemCountryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CountryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        val item = getItem(position)
        if (item != null) {
            holder.bind(item)
        }
    }

    inner class CountryViewHolder(
        private val binding: ItemCountryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(country: Country) {
            binding.tvCountryName.text = country.commonName
            val regionText = buildString {
                append(country.region ?: "Unknown Region")
                if (country.countryCode.isNotEmpty()) {
                    append(" • ").append(country.countryCode)
                }
            }
            binding.tvRegion.text = regionText

            Glide.with(binding.imgFlag.context)
                .load(country.flagUrl)
                .placeholder(R.drawable.ic_flag_placeholder)
                .error(R.drawable.ic_flag_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(binding.imgFlag)

            val isSaved = wishlistCodes.contains(country.countryCode)
            if (isSaved) {
                binding.btnWishlist.setImageResource(R.drawable.ic_favorite_filled)
            } else {
                binding.btnWishlist.setImageResource(R.drawable.ic_favorite_border)
            }

            binding.root.setOnClickListener { onCountryClick(country) }
            binding.btnWishlist.setOnClickListener { onWishlistClick(country) }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Country>() {
        override fun areItemsTheSame(oldItem: Country, newItem: Country): Boolean {
            return oldItem.countryCode == newItem.countryCode
        }

        override fun areContentsTheSame(oldItem: Country, newItem: Country): Boolean {
            return oldItem == newItem
        }
    }
}
