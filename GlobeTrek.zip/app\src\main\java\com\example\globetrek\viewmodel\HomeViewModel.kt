package com.example.globetrek.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.globetrek.data.model.Country
import com.example.globetrek.data.model.Resource
import com.example.globetrek.data.repository.CountryRepository
import com.example.globetrek.data.repository.WishlistRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HomeViewModel(
    private val countryRepository: CountryRepository = CountryRepository(),
    private val wishlistRepository: WishlistRepository = WishlistRepository()
) : ViewModel() {

    private val _countries = MutableLiveData<Resource<List<Country>>>()
    val countries: LiveData<Resource<List<Country>>> = _countries

    private val _selectedRegion = MutableLiveData<String>("All")
    val selectedRegion: LiveData<String> = _selectedRegion

    private val _wishlistCodes = MutableLiveData<Set<String>>(emptySet())
    val wishlistCodes: LiveData<Set<String>> = _wishlistCodes

    private var allCountriesList: List<Country> = emptyList()
    private var searchJob: Job? = null
    private var currentQuery: String = ""

    init {
        loadCountries()
        observeWishlist()
    }

    fun loadCountries() {
        _countries.value = Resource.Loading()
        viewModelScope.launch {
            val result = countryRepository.getAllCountries()
            if (result is Resource.Success && result.data != null) {
                allCountriesList = result.data
                applyFilterAndSearch()
            } else {
                _countries.value = result
            }
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(450)
            currentQuery = newQuery
            if (newQuery.isBlank()) {
                applyFilterAndSearch()
            } else {
                _countries.value = Resource.Loading()
                val result = countryRepository.searchCountries(newQuery)
                if (result is Resource.Success && result.data != null) {
                    val filtered = filterByRegion(result.data, _selectedRegion.value ?: "All")
                    if (filtered.isEmpty()) {
                        _countries.value = Resource.Error("No countries found for \"$newQuery\".")
                    } else {
                        _countries.value = Resource.Success(filtered)
                    }
                } else {
                    _countries.value = result
                }
            }
        }
    }

    fun selectRegion(region: String) {
        _selectedRegion.value = region
        applyFilterAndSearch()
    }

    private fun applyFilterAndSearch() {
        val region = _selectedRegion.value ?: "All"
        val filtered = filterByRegion(allCountriesList, region)
        val searchFiltered = if (currentQuery.isBlank()) {
            filtered
        } else {
            filtered.filter {
                it.commonName.contains(currentQuery, ignoreCase = true) ||
                it.officialName.contains(currentQuery, ignoreCase = true) ||
                it.countryCode.equals(currentQuery, ignoreCase = true)
            }
        }

        if (searchFiltered.isEmpty()) {
            _countries.value = Resource.Error("No countries found in $region region.")
        } else {
            _countries.value = Resource.Success(searchFiltered)
        }
    }

    private fun filterByRegion(list: List<Country>, region: String): List<Country> {
        if (region.equals("All", ignoreCase = true)) return list
        return list.filter { it.region?.equals(region, ignoreCase = true) == true }
    }

    private fun observeWishlist() {
        viewModelScope.launch {
            wishlistRepository.getWishlistFlow().collectLatest { res ->
                if (res is Resource.Success && res.data != null) {
                    _wishlistCodes.value = res.data.map { it.countryCode }.toSet()
                }
            }
        }
    }

    fun toggleWishlist(country: Country) {
        viewModelScope.launch {
            val code = country.countryCode
            val isSaved = _wishlistCodes.value?.contains(code) == true
            if (isSaved) {
                wishlistRepository.removeFromWishlist(code)
            } else {
                wishlistRepository.addToWishlist(country)
            }
        }
    }
}
