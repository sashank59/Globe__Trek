package com.example.globetrek.data.model

import com.google.gson.annotations.SerializedName

data class Country(
    @field:SerializedName("name") val name: CountryName? = null,
    @field:SerializedName("cca2") val cca2: String? = null,
    @field:SerializedName("cca3") val cca3: String? = null,
    @field:SerializedName("capital") val capital: List<String>? = null,
    @field:SerializedName("region") val region: String? = null,
    @field:SerializedName("subregion") val subregion: String? = null,
    @field:SerializedName("population") val population: Long? = null,
    @field:SerializedName("flags") val flags: CountryFlags? = null,
    @field:SerializedName("currencies") val currencies: Map<String, CurrencyInfo>? = null,
    @field:SerializedName("languages") val languages: Map<String, String>? = null
) {
    val commonName: String
        get() = name?.common ?: "Unknown Country"

    val officialName: String
        get() = name?.official ?: commonName

    val flagUrl: String
        get() = flags?.png ?: flags?.svg ?: ""

    val countryCode: String
        get() = cca2 ?: cca3 ?: ""

    val formattedCapital: String
        get() = capital?.joinToString(", ") ?: "N/A"

    val formattedCurrencies: String
        get() = currencies?.entries?.joinToString(", ") { (code, info) ->
            val symbolStr = if (!info.symbol.isNullOrEmpty()) " (${info.symbol})" else ""
            "${info.name ?: code}$symbolStr"
        } ?: "N/A"

    val formattedLanguages: String
        get() = languages?.values?.joinToString(", ") ?: "N/A"
}

data class CountryName(
    @field:SerializedName("common") val common: String? = null,
    @field:SerializedName("official") val official: String? = null
)

data class CountryFlags(
    @field:SerializedName("png") val png: String? = null,
    @field:SerializedName("svg") val svg: String? = null,
    @field:SerializedName("alt") val alt: String? = null
)

data class CurrencyInfo(
    @field:SerializedName("name") val name: String? = null,
    @field:SerializedName("symbol") val symbol: String? = null
)
