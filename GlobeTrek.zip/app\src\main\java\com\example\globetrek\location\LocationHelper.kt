package com.example.globetrek.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import com.example.globetrek.data.model.Resource
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

class LocationHelper(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    fun isLocationEnabled(): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): Resource<Location> = withContext(Dispatchers.IO) {
        if (!isLocationEnabled()) {
            return@withContext Resource.Error("Location services (GPS) are disabled. Please turn on Location in device settings.")
        }

        val cancellationTokenSource = CancellationTokenSource()

        val location: Location? = suspendCancellableCoroutine { continuation ->
            fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                cancellationTokenSource.token
            ).addOnSuccessListener { loc ->
                if (continuation.isActive) continuation.resume(loc)
            }.addOnFailureListener {
                if (continuation.isActive) continuation.resume(null)
            }
        }

        if (location != null) {
            Resource.Success(location)
        } else {
            val lastLoc: Location? = suspendCancellableCoroutine { continuation ->
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (continuation.isActive) continuation.resume(loc)
                }.addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
            }
            if (lastLoc != null) {
                Resource.Success(lastLoc)
            } else {
                Resource.Error("Could not retrieve current location. Please check your GPS and try again.")
            }
        }
    }

    suspend fun getCountryCodeFromLocation(location: Location): Resource<String> = withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val countryCode: String? = suspendCancellableCoroutine { continuation ->
                    geocoder.getFromLocation(
                        location.latitude,
                        location.longitude,
                        1,
                        object : Geocoder.GeocodeListener {
                            override fun onGeocode(addresses: MutableList<Address>) {
                                val code = addresses.firstOrNull()?.countryCode
                                if (continuation.isActive) continuation.resume(code)
                            }

                            override fun onError(errorMessage: String?) {
                                if (continuation.isActive) continuation.resume(null)
                            }
                        }
                    )
                }
                if (!countryCode.isNullOrEmpty()) {
                    Resource.Success(countryCode)
                } else {
                    Resource.Error("Geocoder could not resolve country code from location.")
                }
            } else {
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                val code = addresses?.firstOrNull()?.countryCode
                if (!code.isNullOrEmpty()) {
                    Resource.Success(code)
                } else {
                    Resource.Error("Geocoder could not resolve country code from location.")
                }
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Failed to perform geocoding lookup.")
        }
    }
}
